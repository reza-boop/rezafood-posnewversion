"""Entry point for RezaFood POS v11.3.

Run with:
    python app.py
"""

from __future__ import annotations

import sys
import tkinter as tk

from config import APP_NAME
from db import Database
from ui.login import LoginWindow
from ui.main import PosApp
from utils import ensure_dirs


def main() -> None:
    """Initialise directories, database, and the Tkinter event loop."""
    ensure_dirs()

    db = Database()

    # The root window is hidden; it is used as a transient parent for the
    # login dialog and later replaced by the main application window.
    root = tk.Tk()
    root.withdraw()

    def on_login_success(user: dict) -> None:
        """Callback fired when the user authenticates successfully."""
        db.add_audit_log(user["id"], user["username"], "login", "")

        # Build a fresh Tk window for the main app
        app_root = tk.Tk()
        PosApp(app_root, db, user)
        app_root.protocol("WM_DELETE_WINDOW", lambda: _on_close(app_root, db))
        app_root.mainloop()

        # After the main window closes, re-open the login dialog so another
        # user can log in without restarting the process.
        _restart_login(root, db)

    def _on_close(window: tk.Tk, database: Database) -> None:
        window.destroy()

    def _restart_login(parent: tk.Tk, database: Database) -> None:
        parent.deiconify()
        LoginWindow(parent, database, on_login_success)

    LoginWindow(root, db, on_login_success)
    root.mainloop()


if __name__ == "__main__":
    main()
